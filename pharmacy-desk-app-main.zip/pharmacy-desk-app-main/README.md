# pharmacy-desk-app
A Java Desktop Application built to manage pharmacy inventory, sales, and customer data efficiently. Designed with Java Swing and integrated with a MySQL database using JDBC.
