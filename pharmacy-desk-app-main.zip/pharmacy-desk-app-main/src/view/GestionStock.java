package view;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Controller.medicamentC;
import Controller.stockC;
import model.beans.medicament;
import model.beans.stock1;
public class GestionStock extends JFrame{
	private JPanel lP;
    private JPanel rP;
    private JButton bAjouter;
    private JButton bEnregistrer;
    private JButton bSupprimer;
    private JButton bFermer;
    private JButton bModifier;
    private JTextField tqteS;
    private JTextField tnom;
    private JTextField tstock;
    private JLabel b;
    private JLabel nom;
    private JLabel stock;
    private JLabel qteS;
    private DefaultTableModel modelTable;
    private JTable tableS;
    private List<stock1> allS;
	public GestionStock() {
		this.setTitle("Gestion de stock");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(900, 600));
        this.setLayout(new BorderLayout());

        // Title/Header
        JPanel titre = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titre.setBackground(new Color(34, 49, 63));
        JLabel ltitre = new JLabel("Gestion de stock");
        ltitre.setFont(new Font("Segoe UI", Font.BOLD, 32));
        ltitre.setForeground(new Color(236, 240, 241));
        titre.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        titre.add(ltitre);
        this.add(titre, BorderLayout.NORTH);

        // Left panel (form)
        lP = new JPanel();
        lP.setBackground(new Color(236, 240, 241));
        lP.setPreferredSize(new Dimension(400, 500));
        lP.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        stock = new JLabel("ID de stock");
        stock.setFont(new Font("Segoe UI", Font.BOLD, 16));
        stock.setForeground(new Color(34, 49, 63));
        lP.add(stock, gbc);
        gbc.gridx = 1;
        tstock = new JTextField();
        styleField(tstock);
        lP.add(tstock, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        nom = new JLabel("nom");
        nom.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nom.setForeground(new Color(34, 49, 63));
        lP.add(nom, gbc);
        gbc.gridx = 1;
        tnom = new JTextField();
        styleField(tnom);
        lP.add(tnom, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        qteS = new JLabel("quantité de stock");
        qteS.setFont(new Font("Segoe UI", Font.BOLD, 16));
        qteS.setForeground(new Color(34, 49, 63));
        lP.add(qteS, gbc);
        gbc.gridx = 1;
        tqteS = new JTextField();
        styleField(tqteS);
        lP.add(tqteS, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bAjouter = new JButton("ajouter");
        styleButton(bAjouter);
        lP.add(bAjouter, gbc);
        gbc.gridx = 1;
        bEnregistrer = new JButton("enregistrer");
        styleButton(bEnregistrer);
        lP.add(bEnregistrer, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bModifier = new JButton("modifier");
        styleButton(bModifier);
        lP.add(bModifier, gbc);
        gbc.gridx = 1;
        bSupprimer = new JButton("supprimer");
        styleButton(bSupprimer);
        lP.add(bSupprimer, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bFermer = new JButton("Fermer");
        styleButton(bFermer);
        gbc.gridwidth = 2;
        lP.add(bFermer, gbc);

        // Right panel (table)
        modelTable = new DefaultTableModel(new Object[][]{}, new String[]{"Id stock", "nom","qunatité de stock"});
        load();
        tableS = new JTable(modelTable);
        tableS.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableS.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(tableS);
        rP = new JPanel(new BorderLayout());
        rP.setBackground(new Color(236, 240, 241));
        rP.add(scrollPane, BorderLayout.CENTER);
        rP.setPreferredSize(new Dimension(500, 500));

        this.add(lP, BorderLayout.WEST);
        this.add(rP, BorderLayout.CENTER);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        bModifier.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		try {
        			
                    String tnom1 =tnom.getText().trim();
                    String tstock1 =tstock.getText().trim();
                    String tqteS1 =tqteS.getText().trim();
                    if ( tnom1.length()==0  || tstock1.length()==0 || tqteS1.length()==0) {
                    	JOptionPane.showMessageDialog(null, "chaque donnée doit etre non null","title", JOptionPane.WARNING_MESSAGE);
                    }
                    else {
                    	stockC c = new stockC();
                    	c.modifier(new stock1(Integer.parseInt(tstock1),tnom1,Integer.parseInt(tqteS1)));
                    	}
          
                    }
        		 catch (  SQLException e1) {
        				JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
        			
        		}
        		
            }
        });
        bAjouter.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		try {
        			String tnom1 =tnom.getText().trim();
                    String tstock1 =tstock.getText().trim();
                    String tqteS1 =tqteS.getText().trim();
                    if (tnom1.length()==0  || tstock1.length()==0 || tqteS1.length()==0) {
                    	JOptionPane.showMessageDialog(null, "chaque donnée doit etre non null","title", JOptionPane.WARNING_MESSAGE);
                    }
                    else {
                    	stockC c = new stockC();
                    	c.ajout(new stock1(Integer.parseInt(tstock1),tnom1,Integer.parseInt(tqteS1)));
                    	}
          
                    }
        		 catch (  SQLException e1) {
        				JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
        			
        		}
        		
            }
        });
        bSupprimer.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		try {
        			String tstock1 =tstock.getText().trim();
                    
                    if (tstock1.length()==0 ) {
                    	JOptionPane.showMessageDialog(null, "id stock doit etre non null","title", JOptionPane.WARNING_MESSAGE);
                    }
                    else {
                    	int choix = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cette stock ?",
                                "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
                    	if (choix == JOptionPane.YES_OPTION) {
                    	stockC c = new stockC();
                    	c.supprimer(Integer.parseInt(tstock1));
                    	}
                    }
          
                    }
        		 catch (  SQLException e1) {
        				JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
        			
        		}
        		
            }
        });
        bEnregistrer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				load();
			}
        	
        });
        bFermer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int choix = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de fermer l'app  ?",
                        "Confirmation de fermer", JOptionPane.YES_NO_OPTION);
				if (choix == JOptionPane.YES_OPTION) {
					dispose();
				}
			}
        	
        });
	}
	private void load() {
		try {
			modelTable.setRowCount(0);
			stockC c =new stockC();
			allS = c.lister();
			for (stock1 m : allS) {
                modelTable.addRow(new Object[]{m.getStock(), m.getNom(),m.getQteS() 
                         });
            }
		} catch (SQLException e) {
			 JOptionPane.showMessageDialog(null, e.getMessage(), "title", JOptionPane.ERROR_MESSAGE);
		} 
		
	}
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2, true));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
        });
    }
    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        field.setBackground(Color.WHITE);
    }
}
