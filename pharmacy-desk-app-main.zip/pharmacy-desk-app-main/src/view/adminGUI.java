package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Cursor;

import javax.swing.*;


public class adminGUI extends JFrame{
	private JPanel lP;
    private JPanel titre;
    private JLabel LB;
    private JLabel ltitre;
    private JButton BGC ;
    private JButton BGM ;
    private JButton BGS ;
	public adminGUI() {
		this.setIconImage(new ImageIcon("pict.png").getImage());
        this.setTitle("Admin Interface");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(700, 520));
        titre = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titre.setBackground(new Color(34, 49, 63));
        ltitre = new JLabel("Admin Interface");
        ltitre.setFont(new Font("Segoe UI", Font.BOLD, 32));
        ltitre.setForeground(new Color(236, 240, 241));
        titre.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        titre.add(ltitre);
        this.getContentPane().add(titre, BorderLayout.NORTH);
        
        lP = new JPanel();
        lP.setBackground(new Color(236, 240, 241));
        lP.setPreferredSize(new Dimension(400, 500));
        lP.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel n14=new JLabel("Gestion des clients :");
        n14.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n14.setForeground(new Color(34, 49, 63));
        lP.add(n14, gbc);
        gbc.gridx = 1;
        BGC = new JButton("Gestion des clients");
        styleButton(BGC);
        lP.add(BGC, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel n15=new JLabel("Gestion des médicaments :");
        n15.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n15.setForeground(new Color(34, 49, 63));
        lP.add(n15, gbc);
        gbc.gridx = 1;
        BGM = new JButton("Gestion des médicaments");
        styleButton(BGM);
        lP.add(BGM, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel n16=new JLabel("Gestion du stock :");
        n16.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n16.setForeground(new Color(34, 49, 63));
        lP.add(n16, gbc);
        gbc.gridx = 1;
        BGS = new JButton("Gestion du stock");
        styleButton(BGS);
        lP.add(BGS, gbc);
        BGM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				gestionMed c2= new gestionMed();
				
				
			}
        	
        });
        BGS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				GestionStock c3= new GestionStock();
				
				
			}
        	
        });
        BGC.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				gestionClient c1= new gestionClient();
				
				
			}
        	
        });
        this.add(lP, BorderLayout.CENTER);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
	}
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2, true));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
        });
    }
}
