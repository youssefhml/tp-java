package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import Controller.SignUpC;
import Controller.loginC;
import model.beans.utilisateur;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

public class SignUp extends JFrame {
    private JPanel lP; // left panel
    private JPanel rP; // right panel
    private JLabel tLabel;
    private JLabel nLabel;
    private JTextField nT;
    private JLabel npLabel;
    private JTextField npT;
    private JLabel id;
    private JTextField idT;
    private JLabel passwordL;
    private JPasswordField passwordF;
    private JButton signB;
    private JLabel loginL;
    private JLabel typeLabel;
    private JComboBox<String> typeComboBox;

    public SignUp() {
        this.setTitle("ISIMG Pharmacy SignUp");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(1000, 600));
        this.setLayout(null);
        
        // Create gradient panel for left side
        lP = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(255, 255, 255);
                Color color2 = new Color(240, 240, 250);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        lP.setPreferredSize(new Dimension(500, 600));
        lP.setLayout(null);

        // Modern signup title with shadow effect
        tLabel = new JLabel("Create Account");
        tLabel.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tLabel.setForeground(new Color(51, 51, 51));
        tLabel.setBounds(120, 50, 300, 50);
        lP.add(tLabel);

        // Subtitle
        JLabel subtitle = new JLabel("Join our pharmacy management system");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitle.setForeground(new Color(128, 128, 128));
        subtitle.setBounds(123, 100, 300, 30);
        lP.add(subtitle);

        // Name field
        nLabel = new JLabel("Name");
        nLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        nLabel.setForeground(new Color(51, 51, 51));
        nLabel.setBounds(120, 140, 100, 20);
        lP.add(nLabel);

        nT = new JTextField();
        nT.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nT.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        nT.setBounds(120, 165, 260, 40);
        lP.add(nT);

        // First name field
        npLabel = new JLabel("First Name");
        npLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        npLabel.setForeground(new Color(51, 51, 51));
        npLabel.setBounds(120, 215, 100, 20);
        lP.add(npLabel);

        npT = new JTextField();
        npT.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        npT.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        npT.setBounds(120, 240, 260, 40);
        lP.add(npT);

        // User type field
        typeLabel = new JLabel("User Type");
        typeLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        typeLabel.setForeground(new Color(51, 51, 51));
        typeLabel.setBounds(120, 290, 100, 20);
        lP.add(typeLabel);

        String[] userTypes = {"ADMIN", "PHARMACIEN"};
        typeComboBox = new JComboBox<>(userTypes);
        typeComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        typeComboBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        typeComboBox.setBounds(120, 315, 260, 40);
        typeComboBox.setBackground(Color.WHITE);
        lP.add(typeComboBox);

        // ID field
        id = new JLabel("ID");
        id.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        id.setForeground(new Color(51, 51, 51));
        id.setBounds(120, 365, 100, 20);
        lP.add(id);

        idT = new JTextField();
        idT.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        idT.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        idT.setBounds(120, 390, 260, 40);
        lP.add(idT);

        // Password field
        passwordL = new JLabel("Password");
        passwordL.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        passwordL.setForeground(new Color(51, 51, 51));
        passwordL.setBounds(120, 440, 100, 20);
        lP.add(passwordL);

        passwordF = new JPasswordField();
        passwordF.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordF.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        passwordF.setBounds(120, 465, 260, 40);
        lP.add(passwordF);

        // Sign up button with modern styling
        signB = new JButton("Create Account");
        signB.setBackground(new Color(51, 153, 255));
        signB.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signB.setForeground(Color.WHITE);
        signB.setBounds(120, 520, 260, 45);
        signB.setBorder(BorderFactory.createEmptyBorder());
        signB.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signB.setFocusPainted(false);
        lP.add(signB);

        // Login link
        loginL = new JLabel("Already have an account? Login");
        loginL.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        loginL.setForeground(new Color(51, 153, 255));
        loginL.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginL.setBounds(165, 570, 200, 20);
        lP.add(loginL);

        // Right panel with gradient background
        rP = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(51, 153, 255);
                Color color2 = new Color(0, 102, 204);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        rP.setPreferredSize(new Dimension(500, 600));
        rP.setLayout(null);

        // Logo and branding on right panel
        JLabel logo = new JLabel(new ImageIcon("pic.png"));
        logo.setBounds(150, 150, 200, 200);
        rP.add(logo);

        JLabel brandName = new JLabel("ISIMG Pharmacy");
        brandName.setFont(new Font("Segoe UI", Font.BOLD, 28));
        brandName.setForeground(Color.WHITE);
        brandName.setBounds(150, 370, 250, 40);
        rP.add(brandName);

        JLabel copyright = new JLabel("© 2024 ISIMG Pharmacy. All rights reserved.");
        copyright.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
        copyright.setForeground(new Color(255, 255, 255, 180));
        copyright.setBounds(130, 540, 300, 20);
        rP.add(copyright);

        // Add action listeners
        signB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nom = nT.getText().trim();
                    String prenom = npT.getText().trim();
                    String selectedType = (String) typeComboBox.getSelectedItem();
                    String id = idT.getText().trim();
                    String password = new String(passwordF.getPassword());
                    
                    if (id.isEmpty() || password.isEmpty() || nom.isEmpty() || prenom.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "All fields must be filled", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        int userId = Integer.parseInt(id);
                        String dbType = selectedType.equals("ADMIN") ? "Administrateur" : "Pharmacien";
                        utilisateur user = new utilisateur(userId, password, nom, prenom, dbType);
                        SignUpC s = new SignUpC(user);
                        
                        if(s.ajout()) {
                            JOptionPane.showMessageDialog(null, 
                                "Your account has been created successfully",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE);
                            dispose();
                            EventQueue.invokeLater(() -> {
                                Login login = new Login();
                                login.setVisible(true);
                            });
                        } else {
                            JOptionPane.showMessageDialog(null, 
                                "Account already exists",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        }
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, 
                        "ID must be a number", 
                        "Input Error", 
                        JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, 
                        "Database error: " + ex.getMessage(), 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        loginL.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                EventQueue.invokeLater(() -> {
                    Login login = new Login();
                    login.setVisible(true);
                    dispose();
                });
            }
        });

        // Add panels to frame
        this.add(lP);
        lP.setBounds(0, 0, 500, 600);
        this.add(rP);
        rP.setBounds(500, 0, 500, 600);

        // Final frame setup
        this.setIconImage(new ImageIcon("pict.png").getImage());
        this.pack();
        this.setLocationRelativeTo(null);
    }
}
