package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import Controller.loginC;

public class Login extends JFrame {
    private JPanel lP;
    private JPanel rP;
    private JLabel tL;
    private JLabel id;
    private JTextField idt;
    private JLabel passwordL;
    private JPasswordField passwordF;
    private JLabel signL;
    private JButton signB;
    private JLabel php;
    private JLabel phn;
    private JLabel copyright;
    private JButton lb;

    public Login() {
        this.setTitle("ISIMG Pharmacy Login");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(1000, 600));
        this.setLayout(null);
        
        // Create gradient panel for left side
        lP = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(255, 255, 255);
                Color color2 = new Color(240, 240, 250);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        lP.setPreferredSize(new Dimension(500, 600));
        lP.setLayout(null);

        // Modern login title with shadow effect
        tL = new JLabel("Welcome Back");
        tL.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tL.setForeground(new Color(51, 51, 51));
        tL.setBounds(120, 50, 300, 50);
        lP.add(tL);

        // Subtitle
        JLabel subtitle = new JLabel("Sign in to continue");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitle.setForeground(new Color(128, 128, 128));
        subtitle.setBounds(123, 100, 300, 30);
        lP.add(subtitle);

        // Styled input fields
        id = new JLabel("ID");
        id.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        id.setForeground(new Color(51, 51, 51));
        id.setBounds(120, 160, 100, 20);
        lP.add(id);

        idt = new JTextField();
        idt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        idt.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        idt.setBounds(120, 185, 260, 45);
        lP.add(idt);

        passwordL = new JLabel("Password");
        passwordL.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        passwordL.setForeground(new Color(51, 51, 51));
        passwordL.setBounds(120, 250, 100, 20);
        lP.add(passwordL);

        passwordF = new JPasswordField();
        passwordF.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordF.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(204, 204, 204)),
            new EmptyBorder(5, 10, 5, 10)));
        passwordF.setBounds(120, 275, 260, 45);
        lP.add(passwordF);

        // Modern styled login button
        lb = new JButton("Login");
        lb.setBackground(new Color(51, 153, 255));
        lb.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lb.setForeground(Color.WHITE);
        lb.setBounds(120, 350, 260, 45);
        lb.setBorder(BorderFactory.createEmptyBorder());
        lb.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lb.setFocusPainted(false);
        lP.add(lb);

        // Sign up section with modern styling
        signL = new JLabel("Don't have an account?");
        signL.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        signL.setForeground(new Color(128, 128, 128));
        signL.setBounds(120, 420, 150, 20);
        lP.add(signL);

        signB = new JButton("Sign Up");
        signB.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signB.setForeground(new Color(51, 153, 255));
        signB.setBounds(270, 415, 100, 30);
        signB.setContentAreaFilled(false);
        signB.setBorder(BorderFactory.createEmptyBorder());
        signB.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signB.setFocusPainted(false);
        lP.add(signB);

        // Right panel with gradient background
        rP = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(51, 153, 255);
                Color color2 = new Color(0, 102, 204);
                GradientPaint gp = new GradientPaint(0, 0, color1, w, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        rP.setPreferredSize(new Dimension(500, 600));
        rP.setLayout(null);

        // Logo and branding
        php = new JLabel(new ImageIcon("pic.png"));
        php.setBounds(150, 150, 200, 200);
        rP.add(php);

        phn = new JLabel("ISIMG Pharmacy");
        phn.setFont(new Font("Segoe UI", Font.BOLD, 28));
        phn.setForeground(Color.WHITE);
        phn.setBounds(150, 370, 250, 40);
        rP.add(phn);

        copyright = new JLabel("© 2024 ISIMG Pharmacy. All rights reserved.");
        copyright.setFont(new Font("Segoe UI Light", Font.PLAIN, 12));
        copyright.setForeground(new Color(255, 255, 255, 180));
        copyright.setBounds(130, 540, 300, 20);
        rP.add(copyright);

        // Add action listeners
        lb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        signB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            SignUp signUpFrame = new SignUp();
                            signUpFrame.setVisible(true);
                            dispose();
                        } catch (Exception ex) {
                            System.err.println("Error creating SignUp window: " + ex.getMessage());
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(Login.this,
                                "Error opening SignUp window: " + ex.getMessage(),
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
            }
        });

        // Add panels to frame
        this.add(lP);
        lP.setBounds(0, 0, 500, 600);
        this.add(rP);
        rP.setBounds(500, 0, 500, 600);
        
        // Final frame setup
        this.setIconImage(new ImageIcon("pict.png").getImage());
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void handleLogin() {
        try {
            String login = idt.getText();
            String password = new String(passwordF.getPassword());
            if (login.isEmpty() || password.isEmpty()) {
                showError("Please enter both ID and password", "Validation Error");
                return;
            }

            loginC loginc = new loginC(login, password);
            String type = loginc.getType();

            switch (type) {
                case "erro1":
                    showError("Account not found", "Authentication Error");
                    break;
                case "erro2":
                    showError("Incorrect password", "Authentication Error");
                    break;
                case "Pharmacien":
                    new pharmacienGUI();
                    dispose();
                    break;
                case "Administrateur":
                    new adminGUI();
                    dispose();
                    break;
            }
        } catch (NumberFormatException e) {
            showError("ID must be a number", "Input Error");
        } catch (SQLException e) {
            showError("Database error: " + e.getMessage(), "System Error");
        }
    }

    private void showError(String message, String title) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new Login();
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null,
                        "Error starting application: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
