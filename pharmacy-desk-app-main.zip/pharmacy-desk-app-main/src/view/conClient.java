package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Controller.clientC;
import Controller.loginC;
import model.beans.client;

public class conClient extends JFrame{
	private JPanel lP;
    private JPanel rP;
    private JTextField nom;
    private JTextField prenom;
    private JButton bR;
    private JTable tableClients;
    private DefaultTableModel modelTable;
    private List<client> allClients;
    private JLabel nomL;
    private JLabel prenomL;
    private JLabel BL;
    private JLabel b;
	public conClient() {
		this.setTitle("Client consultation");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(900, 600));
        this.setLayout(new BorderLayout());

        // Title/Header
        JPanel titre = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titre.setBackground(new Color(34, 49, 63));
        JLabel ltitre = new JLabel("Consultation de clients");
        ltitre.setFont(new Font("Segoe UI", Font.BOLD, 32));
        ltitre.setForeground(new Color(236, 240, 241));
        titre.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        titre.add(ltitre);
        this.add(titre, BorderLayout.NORTH);

        // Left panel (form)
        lP = new JPanel();
        lP.setBackground(new Color(236, 240, 241));
        lP.setPreferredSize(new Dimension(400, 500));
        lP.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        nomL = new JLabel("Nom");
        nomL.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nomL.setForeground(new Color(34, 49, 63));
        lP.add(nomL, gbc);
        gbc.gridx = 1;
        nom = new JTextField();
        styleField(nom);
        lP.add(nom, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        prenomL = new JLabel("Prénom");
        prenomL.setFont(new Font("Segoe UI", Font.BOLD, 16));
        prenomL.setForeground(new Color(34, 49, 63));
        lP.add(prenomL, gbc);
        gbc.gridx = 1;
        prenom = new JTextField();
        styleField(prenom);
        lP.add(prenom, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bR = new JButton("CHERCHER");
        styleButton(bR);
        lP.add(bR, gbc);
        gbc.gridx = 1;
        JButton fermerBtn = new JButton("FERMER");
        styleButton(fermerBtn);
        fermerBtn.setBackground(new Color(153, 0, 0));
        fermerBtn.setForeground(Color.WHITE);
        lP.add(fermerBtn, gbc);

        // Right panel (table)
        modelTable = new DefaultTableModel(new Object[][]{}, new String[]{"Id", "Nom", "Prénom", "Crédit"});
        clientC c = new clientC();
        try {
            allClients = c.lister();
            for (client client : allClients) {
                modelTable.addRow(new Object[]{client.getIdclient(), client.getNom(), client.getPrenom(), client.getCredit()});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "title", JOptionPane.ERROR_MESSAGE);
        }
        tableClients = new JTable(modelTable);
        tableClients.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableClients.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(tableClients);
        rP = new JPanel(new BorderLayout());
        rP.setBackground(new Color(236, 240, 241));
        rP.add(scrollPane, BorderLayout.CENTER);
        rP.setPreferredSize(new Dimension(500, 500));

        this.add(lP, BorderLayout.WEST);
        this.add(rP, BorderLayout.CENTER);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        fermerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new pharmacienGUI();
            }
        });
        bR.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nomr = nom.getText().trim();
                    String prenomr = prenom.getText().trim();
                    if (nomr.length() == 0 || prenomr.length() == 0) {
                        JOptionPane.showMessageDialog(null, "enter nom and prenom !", "title", JOptionPane.WARNING_MESSAGE);
                    } else {
                        List<client> clients = c.filter(allClients, nomr, prenomr);
                        modelTable.setRowCount(0);
                        for (client client : clients) {
                            modelTable.addRow(new Object[]{client.getIdclient(), client.getNom(), client.getPrenom(), client.getCredit()});
                        }
                    }
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2, true));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
        });
    }
    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        field.setBackground(Color.WHITE);
    }
}
