package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class pharmacienGUI extends JFrame {
    private JPanel lP;
    private JButton BCC;
    private JButton BCM;
    private JButton BGO;
    private JPanel titre;
    private JLabel ltitre;
    public pharmacienGUI() {
        this.setIconImage(new ImageIcon("pict.png").getImage());
        this.setTitle("Pharmacien Interface");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(700, 520));
        titre = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titre.setBackground(new Color(34, 49, 63));
        ltitre = new JLabel("Pharmacien Interface");
        ltitre.setFont(new Font("Segoe UI", Font.BOLD, 32));
        ltitre.setForeground(new Color(236, 240, 241));
        titre.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        titre.add(ltitre);
        this.getContentPane().add(titre, BorderLayout.NORTH);
        lP = new JPanel();
        lP.setBackground(new Color(236, 240, 241));
        lP.setPreferredSize(new Dimension(400, 500));
        lP.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel n14=new JLabel("Consulter les clients :");
        n14.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n14.setForeground(new Color(34, 49, 63));
        lP.add(n14, gbc);
        gbc.gridx = 1;
        BCC = new JButton("Consulter les clients");
        styleButton(BCC);
        lP.add(BCC, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel n15=new JLabel("Consulter les médicaments :");
        n15.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n15.setForeground(new Color(34, 49, 63));
        lP.add(n15, gbc);
        gbc.gridx = 1;
        BCM = new JButton("Consulter les médicaments");
        styleButton(BCM);
        lP.add(BCM, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel n16=new JLabel("Gérer les ordonnances :");
        n16.setFont(new Font("Segoe UI", Font.BOLD, 20));
        n16.setForeground(new Color(34, 49, 63));
        lP.add(n16, gbc);
        gbc.gridx = 1;
        BGO = new JButton("Gérer les ordonnances");
        styleButton(BGO);
        lP.add(BGO, gbc);
        BCM.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                conMed c1= new conMed();
            }
        });
        BGO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestionOrd c2= new gestionOrd();
            }
        });
        BCC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                conClient c3= new conClient();
            }
        });
        this.add(lP, BorderLayout.CENTER);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2, true));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
        });
    }
}
