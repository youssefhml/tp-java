package view;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.*;
import Controller.OrdC;
import Controller.ordC1;
import model.beans.ligne_ord;
import model.beans.ordonnance;
import model.entity.ordonanceDAO;

import javax.swing.table.DefaultTableModel;
public class gestionOrd extends JFrame{
	private JPanel lP;
    private JPanel rP;
    private JButton bAjouter;
    private JButton bEnregistrer;
    private JButton bSupprimer;
    private JButton bFermer;
    private JButton bModifier;
    private JTextField tido;
    private JTextField tidm;
    private JTextField tqt;
    private JTextField tidc;
    private JTextField tidp;
    private JLabel b;
    private JLabel ido;
    private JLabel idm;
    private JLabel qt;
    private JLabel idc;
    private JLabel idp;
    private DefaultTableModel modelTable;
    private JTable tableOrd;
    private List<OrdC> allOrd;
	public gestionOrd() {
		this.setTitle("Gestion d'ordonnance");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(900, 600));
        this.setLayout(new BorderLayout());

        // Title/Header
        JPanel titre = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titre.setBackground(new Color(34, 49, 63));
        JLabel ltitre = new JLabel("Gestion d'ordonnance");
        ltitre.setFont(new Font("Segoe UI", Font.BOLD, 32));
        ltitre.setForeground(new Color(236, 240, 241));
        titre.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        titre.add(ltitre);
        this.add(titre, BorderLayout.NORTH);

        // Left panel (form)
        lP = new JPanel();
        lP.setBackground(new Color(236, 240, 241));
        lP.setPreferredSize(new Dimension(400, 500));
        lP.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        ido = new JLabel("ID d'ordonnance");
        ido.setFont(new Font("Segoe UI", Font.BOLD, 16));
        ido.setForeground(new Color(34, 49, 63));
        lP.add(ido, gbc);
        gbc.gridx = 1;
        tido = new JTextField();
        styleField(tido);
        lP.add(tido, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        idc = new JLabel("ID de client");
        idc.setFont(new Font("Segoe UI", Font.BOLD, 16));
        idc.setForeground(new Color(34, 49, 63));
        lP.add(idc, gbc);
        gbc.gridx = 1;
        tidc = new JTextField();
        styleField(tidc);
        lP.add(tidc, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        idp = new JLabel("ID de pharmacien");
        idp.setFont(new Font("Segoe UI", Font.BOLD, 16));
        idp.setForeground(new Color(34, 49, 63));
        lP.add(idp, gbc);
        gbc.gridx = 1;
        tidp = new JTextField();
        styleField(tidp);
        lP.add(tidp, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        idm = new JLabel("ID de medicament");
        idm.setFont(new Font("Segoe UI", Font.BOLD, 16));
        idm.setForeground(new Color(34, 49, 63));
        lP.add(idm, gbc);
        gbc.gridx = 1;
        tidm = new JTextField();
        styleField(tidm);
        lP.add(tidm, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        qt = new JLabel("Quantité");
        qt.setFont(new Font("Segoe UI", Font.BOLD, 16));
        qt.setForeground(new Color(34, 49, 63));
        lP.add(qt, gbc);
        gbc.gridx = 1;
        tqt = new JTextField();
        styleField(tqt);
        lP.add(tqt, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bAjouter = new JButton("ajouter");
        styleButton(bAjouter);
        lP.add(bAjouter, gbc);
        gbc.gridx = 1;
        bEnregistrer = new JButton("enregistrer");
        styleButton(bEnregistrer);
        lP.add(bEnregistrer, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bModifier = new JButton("modifier");
        styleButton(bModifier);
        lP.add(bModifier, gbc);
        gbc.gridx = 1;
        bSupprimer = new JButton("supprimer");
        styleButton(bSupprimer);
        lP.add(bSupprimer, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        bFermer = new JButton("Fermer");
        styleButton(bFermer);
        gbc.gridwidth = 2;
        lP.add(bFermer, gbc);

        // Right panel (table)
        modelTable = new DefaultTableModel(new Object[][]{}, new String[]{"Id ordonnance", "Id client","Id medicament","quantité"});
        load();    
        tableOrd = new JTable(modelTable);
        tableOrd.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableOrd.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(tableOrd);
        rP = new JPanel(new BorderLayout());
        rP.setBackground(new Color(236, 240, 241));
        rP.add(scrollPane, BorderLayout.CENTER);
        rP.setPreferredSize(new Dimension(500, 500));

        this.add(lP, BorderLayout.WEST);
        this.add(rP, BorderLayout.CENTER);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        bAjouter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int idClient = Integer.parseInt(tidc.getText().trim());
                    int idOrd = Integer.parseInt(tido.getText().trim());
                    int idPharmacien = Integer.parseInt(tidp.getText().trim());
                    int idMed = Integer.parseInt(tidm.getText().trim());
                    int quantite = Integer.parseInt(tqt.getText().trim());

                    ordonnance ord = new ordonnance(idOrd, idClient, idPharmacien);
                    ligne_ord ligne = new ligne_ord(idMed, idOrd, quantite);

                    ordonanceDAO dao = new ordonanceDAO();
                    dao.ajouterOrd(ord, ligne);

                    JOptionPane.showMessageDialog(null, "Ordonnance ajoutée avec succès!");
                } catch (Exception ex) {
                    ex.printStackTrace(); // See full error in console
                    JOptionPane.showMessageDialog(null, "Erreur: " + ex.getMessage(),
                            "Erreur d'insertion", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        bEnregistrer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                load();
            }
        });
        bFermer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choix = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de fermer l'app  ?",
                        "Confirmation de fermer", JOptionPane.YES_NO_OPTION);
                if (choix == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });
        bModifier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String tido1 = tido.getText().trim();
                    String tidc1 = tidc.getText().trim();
                    String tidp1 = tidp.getText().trim();
                    String tidm1 = tidm.getText().trim();
                    String qt1 = tqt.getText().trim();
                    if (tido1.length() == 0 || tidc1.length() == 0 || tidp1.length() == 0 || tidm1.length() == 0 || qt1.length() == 0) {
                        JOptionPane.showMessageDialog(null, "chaque donnée doit etre non null", "title", JOptionPane.WARNING_MESSAGE);
                    } else {
                        ordC1 c = new ordC1();
                        c.modifier(new ordonnance(Integer.parseInt(tido1), Integer.parseInt(tidc1), Integer.parseInt(tidp1)), new ligne_ord(Integer.parseInt(tidm1), Integer.parseInt(tido1), Integer.parseInt(qt1)));
                    }
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        bSupprimer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String tido1 = tido.getText().trim();
                    if (tido1.length() == 0) {
                        JOptionPane.showMessageDialog(null, "id d'ordonnance doit etre non null", "title", JOptionPane.WARNING_MESSAGE);
                    } else {
                        int choix = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cette ordonnance  ?",
                                "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
                        if (choix == JOptionPane.YES_OPTION) {
                            ordC1 c = new ordC1();
                            c.supprimer(Integer.parseInt(tido1));
                        }
                    }
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(null, "there is a problem in your data", "title", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
	}
	public void load(){
		try {
			modelTable.setRowCount(0);
        	ordonanceDAO c = new ordonanceDAO();
			allOrd = c.listerOrdonnances();
			for (OrdC ord : allOrd) {
                modelTable.addRow(new Object[]{ord.getId_ordonnance(), ord.getIdclient(), ord.getId_medicament(),
                		ord.getQuantité()});
            }
		} catch (SQLException e) {
			 JOptionPane.showMessageDialog(null, e.getMessage(), "title", JOptionPane.ERROR_MESSAGE);
		}
	}
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2, true));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
        });
    }
    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        field.setBackground(Color.WHITE);
    }
}
