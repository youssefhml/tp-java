package pharmacy.model;

public class Utilisateur {

}
