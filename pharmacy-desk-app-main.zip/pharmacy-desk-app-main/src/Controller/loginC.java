package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.entity.connexion;

public class loginC {
    private String userType;
    private static final int MAX_LOGIN_ATTEMPTS = 3;
    private static int loginAttempts = 0;

    public loginC(String id, String password) throws SQLException {
        if (id == null || password == null || id.trim().isEmpty() || password.trim().isEmpty()) {
            this.userType = null;
            return;
        }

        if (loginAttempts >= MAX_LOGIN_ATTEMPTS) {
            this.userType = null;
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = connexion.getInstance();
            String sql = "SELECT * FROM utilisateur WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id.trim());
            rs = pstmt.executeQuery();

            if (!rs.next()) {
                loginAttempts++;
                this.userType = null;
            } else {
                String dbPassword = rs.getString("motDePasse");
                if (!dbPassword.equals(password)) {
                    loginAttempts++;
                    this.userType = null;
                } else {
                    loginAttempts = 0;
                    this.userType = rs.getString("typeUtilisateur");
                }
            }
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) { /* ignore */ }
            if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { /* ignore */ }
        }
    }

    public String getUserType() {
        return userType;
    }

    public String getType() {
        return userType != null ? userType : "erro1";
    }

    public static void resetLoginAttempts() {
        loginAttempts = 0;
    }

    public static boolean isAccountLocked() {
        return loginAttempts >= MAX_LOGIN_ATTEMPTS;
    }
}