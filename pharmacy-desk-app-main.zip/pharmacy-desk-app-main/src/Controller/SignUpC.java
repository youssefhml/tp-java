package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.beans.utilisateur;
import model.entity.connexion;

public class SignUpC {
    private utilisateur user;
 
    public SignUpC(utilisateur user) {
        this.user = user;
    }

    public boolean ajout() throws SQLException {
        if (!validateUser()) {
            return false;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = connexion.getInstance();
            String sql = "INSERT INTO utilisateur (id_user, login, password1, nom, prenom, type1) VALUES (?, ?, ?, ?, ?, ?)";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, user.getId_user());
            pstmt.setString(2, String.valueOf(user.getId_user())); // Using ID as login
            pstmt.setString(3, user.getPassword());
            pstmt.setString(4, user.getNom());
            pstmt.setString(5, user.getPrenom());
            pstmt.setString(6, user.getType());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "Error creating account: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    // Log the error
                    System.err.println("Error closing statement: " + e.getMessage());
                }
            }
        }
    }

    private boolean validateUser() {
        if (user.getNom() == null || user.getNom().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Name is required", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (user.getPrenom() == null || user.getPrenom().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "First name is required", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Password is required", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (user.getType() == null || user.getType().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "User type is required", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
}