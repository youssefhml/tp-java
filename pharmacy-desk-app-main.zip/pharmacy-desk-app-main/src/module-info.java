/**
 * 
 */
/**
 * 
 */
module Project {
	requires java.sql;
	requires java.desktop;
}