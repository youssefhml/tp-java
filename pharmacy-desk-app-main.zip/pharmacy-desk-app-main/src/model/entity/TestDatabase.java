package model.entity;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestDatabase {
    public static void main(String[] args) {
        try {
            Connection conn = connexion.getInstance();
            if (conn != null) {
                System.out.println("✅ Connected to database successfully!");
                
                // Get database metadata
                DatabaseMetaData metaData = conn.getMetaData();
                ResultSet tables = metaData.getTables(null, null, "medicament", null);
                
                if (tables.next()) {
                    System.out.println("✅ Medicament table exists");
                    
                    // Get column information
                    ResultSet columns = metaData.getColumns(null, null, "medicament", null);
                    System.out.println("\nTable structure:");
                    System.out.println("----------------");
                    while (columns.next()) {
                        String columnName = columns.getString("COLUMN_NAME");
                        String columnType = columns.getString("TYPE_NAME");
                        System.out.println(columnName + " (" + columnType + ")");
                    }
                    
                    // Get table data
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT * FROM medicament");
                    
                    System.out.println("\nTable data:");
                    System.out.println("-----------");
                    while (rs.next()) {
                        int id = rs.getInt("Id_medicament");
                        String nom = rs.getString("nom");
                        int stock = rs.getInt("stock");
                        double prix = rs.getDouble("prix");
                        System.out.println(id + " | " + nom + " | " + stock + " | " + prix);
                    }
                } else {
                    System.out.println("❌ Medicament table not found!");
                }
            } else {
                System.out.println("❌ Failed to connect to database!");
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
} 