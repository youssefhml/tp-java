package model.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AfficherUtilisateurs {
    public static void main(String[] args) {
        String sql = "SELECT id, nom, prenom, login, typeUtilisateur FROM utilisateur";

        // ✅ Utiliser la connexion via votre classe connexion
        try (Connection conn = connexion.getInstance();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("Liste des utilisateurs:");
            System.out.println("-------------------------------------------------------------");
            System.out.printf("%-5s %-15s %-15s %-15s %-15s%n", 
                "ID", "Nom", "Prénom", "Login", "Type");
            System.out.println("-------------------------------------------------------------");

            // ✅ Lire 'login' comme une chaîne de caractères (String)
            while (rs.next()) {
                int id = rs.getInt("id");
                String nom = rs.getString("nom");
                String prenom = rs.getString("prenom");
                String login = rs.getString("login"); // ✅ Corrigé ici
                String type = rs.getString("typeUtilisateur");

                System.out.printf("%-5d %-15s %-15s %-15s %-15s%n", 
                    id, nom, prenom, login, type);
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de l'affichage des utilisateurs: " + e.getMessage());
        }
    }
}
