package model.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import model.beans.medicament;


public class medicamentDAO {
	private static Connection connection;
	public medicamentDAO() {
		connection = connexion.getInstance();
	}
	public void ajouterMed(medicament med) throws SQLException {
		try {
		    String query = "INSERT INTO medicament (nom, description, prix, quantite_stock, idAdmin) VALUES (?, ?, ?, ?, ?)";
		    PreparedStatement statement = connection.prepareStatement(query);
		    statement.setString(1, med.getNom());
		    statement.setString(2, med.getDescription());
		    statement.setDouble(3, med.getPrix());
		    statement.setInt(4, med.getQuantiteStock());
		    if (med.getIdAdmin() != null) {
		        statement.setInt(5, med.getIdAdmin());
		    } else {
		        statement.setNull(5, java.sql.Types.INTEGER);
		    }
		    statement.executeUpdate();
		} catch (SQLException e1) {
		    JOptionPane.showMessageDialog(null, "Error occurred while inserting data: " + e1.getMessage(),
		                                    "Database Error", JOptionPane.ERROR_MESSAGE);
		    throw e1;
		}
    }
	public void supprimerMed(int id) throws SQLException {
        String query = "DELETE FROM medicament WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        statement.executeUpdate();
    }
	public void modifierMed(medicament med) throws SQLException {
        String query = "UPDATE medicament SET nom = ?, description = ?, prix = ?, quantite_stock = ?, idAdmin = ? WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
	    statement.setString(1, med.getNom());
	    statement.setString(2, med.getDescription());
	    statement.setDouble(3, med.getPrix());
	    statement.setInt(4, med.getQuantiteStock());
	    if (med.getIdAdmin() != null) {
	        statement.setInt(5, med.getIdAdmin());
	    } else {
	        statement.setNull(5, java.sql.Types.INTEGER);
	    }
	    statement.setInt(6, med.getId());
        statement.executeUpdate();
    }
	 public medicament trouverMed(int id) throws SQLException {
	        String query = "SELECT * FROM medicament WHERE id = ?";
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, id);
	        ResultSet resultSet = statement.executeQuery();
	        if (resultSet.next()) {
	            String nom = resultSet.getString("nom");
	            String description = resultSet.getString("description");
	            int quantite_stock = resultSet.getInt("quantite_stock");
	            double prix = resultSet.getDouble("prix");
	            Integer idAdmin = resultSet.getInt("idAdmin");
	            if (resultSet.wasNull()) {
	                idAdmin = null;
	            }
	            
	            return new medicament(id, nom, description, prix, quantite_stock, idAdmin);
	        }
	        return null;
	    }
	 public List<medicament> listerMed() throws SQLException {
	        String query = "SELECT * FROM medicament";
	        Statement statement = connection.createStatement();
	        ResultSet resultSet = statement.executeQuery(query);
	        List<medicament> medicaments = new ArrayList<>();
	        while (resultSet.next()) {
	            int id = resultSet.getInt("id");
	            String nom = resultSet.getString("nom");
	            String description = resultSet.getString("description");
	            int quantite_stock = resultSet.getInt("quantite_stock");
	            double prix = resultSet.getDouble("prix");
	            Integer idAdmin = resultSet.getInt("idAdmin");
	            if (resultSet.wasNull()) {
	                idAdmin = null;
	            }
	            
	            medicaments.add(new medicament(id, nom, description, prix, quantite_stock, idAdmin));
	        }
	        return medicaments;
	    }

}
