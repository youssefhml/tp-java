package model.entity;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

import Controller.OrdC;
import model.beans.ligne_ord;
import model.beans.ordonnance;

public class ordonanceDAO {
    private static Connection connection;

    public ordonanceDAO() {
        connection = connexion.getInstance();
    }

    public void ajouterOrd(ordonnance ordonnance1, ligne_ord c) throws SQLException {
        try {
            if (trouverOrd(ordonnance1.getId_ordonnance()) == null) {
                String query = "INSERT INTO ordonnance (id, idClient, date, idPharmacien) VALUES (?, ?, ?, ?)";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setInt(1, ordonnance1.getId_ordonnance());
                statement.setInt(2, ordonnance1.getIdclient());
                statement.setDate(3, new java.sql.Date(System.currentTimeMillis()));
                statement.setInt(4, ordonnance1.getIdPharmacien());
                statement.executeUpdate();
            }

            // Check if ligneordonnance already exists
            String checkQuery = "SELECT COUNT(*) FROM ligneordonnance WHERE idMedicament = ? AND idOrdonnance = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, c.getId_medicament());
            checkStmt.setInt(2, c.getId_ordonnance());
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                // Insert if not exists
                String insertQuery = "INSERT INTO ligneordonnance (idMedicament, idOrdonnance, quantite) VALUES (?, ?, ?)";
                PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
                insertStmt.setInt(1, c.getId_medicament());
                insertStmt.setInt(2, c.getId_ordonnance());
                insertStmt.setInt(3, c.getQuantité());
                insertStmt.executeUpdate();
            } else {
                // Update if exists
                String updateQuery = "UPDATE ligneordonnance SET quantite = ? WHERE idMedicament = ? AND idOrdonnance = ?";
                PreparedStatement updateStmt = connection.prepareStatement(updateQuery);
                updateStmt.setInt(1, c.getQuantité());
                updateStmt.setInt(2, c.getId_medicament());
                updateStmt.setInt(3, c.getId_ordonnance());
                updateStmt.executeUpdate();
            }

        } catch (SQLException e1) {
            JOptionPane.showMessageDialog(null, "Error occurred while inserting data: " + e1.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            throw e1;
        }
    }

    public void supprimerOrd(int id) throws SQLException {
        // D'abord supprimer les lignes dépendantes
        String query1 = ""
        		+ " FROM ligneordonnance WHERE idOrdonnance = ?";
        PreparedStatement statement1 = connection.prepareStatement(query1);
        statement1.setInt(1, id);
        statement1.executeUpdate();

        // Puis supprimer l'ordonnance
        String query = "DELETE FROM ordonnance WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        statement.executeUpdate();
    }

    public void modifierOrd(ordonnance ordonnance1, ligne_ord c) throws SQLException {
        String query = "UPDATE ordonnance SET idClient = ?, idPharmacien = ? WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, ordonnance1.getIdclient());
        statement.setInt(2, ordonnance1.getIdPharmacien());
        statement.setInt(3, ordonnance1.getId_ordonnance());
        statement.executeUpdate();

        String query1 = "UPDATE ligneordonnance SET idMedicament = ?, quantite = ? WHERE idOrdonnance = ?";
        PreparedStatement statement1 = connection.prepareStatement(query1);
        statement1.setInt(1, c.getId_medicament());
        statement1.setInt(2, c.getQuantité());
        statement1.setInt(3, c.getId_ordonnance());
        statement1.executeUpdate();
    }

    public ordonnance trouverOrd(int id) throws SQLException {
        String query = "SELECT * FROM ordonnance WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            int id_c = resultSet.getInt("idClient");
            int id_p = resultSet.getInt("idPharmacien");
            return new ordonnance(id, id_c, id_p);
        }
        return null;
    }

    public static List<OrdC> listerOrdonnances() throws SQLException {
        String query = "SELECT * FROM ordonnance O JOIN ligneordonnance L ON L.idOrdonnance = O.id";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        List<OrdC> ordonnances = new ArrayList<>();
        while (resultSet.next()) {
            int idMedicament = resultSet.getInt("idMedicament");
            int idClient = resultSet.getInt("idClient");
            int quantite = resultSet.getInt("quantite");
            int Id_ordonnance = resultSet.getInt("idOrdonnance");

            OrdC ordonnance = new OrdC(Id_ordonnance, idClient, idMedicament, quantite);
            ordonnances.add(ordonnance);
        }
        return ordonnances;
    }
}
