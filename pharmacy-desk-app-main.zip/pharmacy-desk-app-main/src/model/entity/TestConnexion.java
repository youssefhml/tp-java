package model.entity;


import model.entity.connexion;
import java.sql.Connection;

public class TestConnexion {
    public static void main(String[] args) {
        Connection conn = connexion.getInstance();

        if (conn != null) {
            System.out.println("✅ Connexion à la base de données réussie.");
        } else {
            System.out.println("❌ Échec de la connexion à la base de données.");
        }
    }
}

