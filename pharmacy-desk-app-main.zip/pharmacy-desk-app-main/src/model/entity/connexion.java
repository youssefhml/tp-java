package model.entity;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.swing.*;

public class connexion {
	private static Properties props = new Properties();
	private static String user;
	private static String password;
	private static String url;
	private static Connection connect;
	
	private connexion() {
	    FileInputStream fis = null;
	    try {
			fis = new FileInputStream("conf.properties");
			props.load(fis);
			url = props.getProperty("jdbc.url");
			user = props.getProperty("jdbc.user");
			password = props.getProperty("jdbc.password");
			
			// Validate configuration
			if (url == null || user == null || password == null) {
			    throw new IOException("Missing required database configuration properties");
			}
			
			connect = DriverManager.getConnection(url, user, password);
		} 
		catch (SQLException e) { 	
			JOptionPane.showMessageDialog(null, 
			    "Database Connection Error: " + e.getMessage(),
			    "Database Error",
			    JOptionPane.ERROR_MESSAGE);
		}
		catch(IOException e) {
			JOptionPane.showMessageDialog(null, 
			    "Configuration Error: " + e.getMessage(),
			    "Configuration Error",
			    JOptionPane.ERROR_MESSAGE);
		}
		finally {
		    if (fis != null) {
		        try {
		            fis.close();
		        } catch (IOException e) {
		            // Log the error but don't show to user as it's not critical
		            System.err.println("Error closing configuration file: " + e.getMessage());
		        }
		    }
		}
	}
	
	public static Connection getInstance() {
		if(connect == null) {
			new connexion();
		}
		return connect;
	}
	
	// Add method to properly close connection
	public static void closeConnection() {
	    if (connect != null) {
	        try {
	            connect.close();
	            connect = null;
	        } catch (SQLException e) {
	            System.err.println("Error closing database connection: " + e.getMessage());
	        }
	    }
	}
}
