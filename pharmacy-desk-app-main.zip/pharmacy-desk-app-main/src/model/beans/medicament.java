package model.beans;

public class medicament {
	
	private int id;
    private String nom;
    private String description;
    private double prix;
    private int quantite_stock;
    private Integer idAdmin;  // Using Integer to allow NULL

	// Full constructor with ID
	public medicament(int id, String nom, String description, double prix, int quantite_stock, Integer idAdmin) {
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.prix = prix;
		this.quantite_stock = quantite_stock;
		this.idAdmin = idAdmin;
	}

	// Constructor without ID (for new records)
	public medicament(String nom, String description, double prix, int quantite_stock, Integer idAdmin) {
		this.nom = nom;
		this.description = description;
		this.prix = prix;
		this.quantite_stock = quantite_stock;
		this.idAdmin = idAdmin;
	}

	// Legacy constructors for backward compatibility
	public medicament(int id, String nom, int quantite_stock, double prix) {
		this.id = id;
		this.nom = nom;
		this.description = null;
		this.prix = prix;
		this.quantite_stock = quantite_stock;
		this.idAdmin = null;
	}

	public medicament(String nom, int quantite_stock, double prix) {
		this.nom = nom;
		this.description = null;
		this.prix = prix;
		this.quantite_stock = quantite_stock;
		this.idAdmin = null;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getQuantiteStock() {
		return quantite_stock;
	}

	public void setQuantiteStock(int quantite_stock) {
		this.quantite_stock = quantite_stock;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getIdAdmin() {
		return idAdmin;
	}

	public void setIdAdmin(Integer idAdmin) {
		this.idAdmin = idAdmin;
	}
}
