package model.beans;

public class administrateur extends utilisateur {
	public administrateur(int id_user, String password, String nom, String prenom, String type, int id_admin) {
		super(id_user, password, nom, prenom, type);
		
	}
	
	
	

}
