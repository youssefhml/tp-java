package model.beans;

public class pharmacien extends utilisateur {

	public pharmacien(int id_user, String password, String nom, String prenom, String type) {
		super(id_user, password, nom, prenom, type);
		
	}
	
	
}
