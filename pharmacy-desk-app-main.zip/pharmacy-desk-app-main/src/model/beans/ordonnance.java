package model.beans;

public class ordonnance {
	private int Id_ordonnance ;
    private int Idclient ;
    private int idPharmacien;
	public ordonnance(int id_ordonnance, int idclient, int idPharmacien ) {
		super();
		Id_ordonnance = id_ordonnance;
		Idclient = idclient;
		this.idPharmacien = idPharmacien;
	}
	public int getId_ordonnance() {
		return Id_ordonnance;
	}
	public void setId_ordonnance(int id_ordonnance) {
		Id_ordonnance = id_ordonnance;
	}
	public int getIdclient() {
		return Idclient;
	}
	public void setIdclient(int idclient) {
		Idclient = idclient;
	}
	public int getIdPharmacien() {
		return idPharmacien;
	}
	public void setIdPharmacien(int idPharmacien) {
		this.idPharmacien = idPharmacien;
	}
    
}
